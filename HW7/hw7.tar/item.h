#ifndef item_H
#define item_H

#include "imports.h"

class item {
    public: 
        int numNikeShoes = 22, numArmourShirt = 33, numBrookShoes = 11, numAsics = 20, numNikeShorts = 77;
        double nikeShoesCost = 145.99, armourCost = 29.99, brooksCost = 111.44, asicsCost = 165.88, nikeShortsCost = 45.77;

};

#endif